# Cache de archivos procesados (parquet, json intermedios).
# El contenido NO se sube a GitHub.
