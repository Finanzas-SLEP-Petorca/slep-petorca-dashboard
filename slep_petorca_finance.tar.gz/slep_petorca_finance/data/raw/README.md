# Esta carpeta contiene los reportes SIGFE descargados, organizados por fecha de corte.
# Estructura sugerida:
#
#   data/raw/
#   ├── 2026-01-31/        # Snapshot enero
#   ├── 2026-02-28/        # Snapshot febrero  
#   ├── 2026-03-31/        # Snapshot marzo
#   ├── 2026-04-30/        # Snapshot abril
#   └── saldos_diarios.csv # Saldos BancoEstado del día
#
# IMPORTANTE: el contenido de esta carpeta NO se sube a GitHub (ver .gitignore).
# Los datos son sensibles y deben permanecer locales o en almacenamiento privado.
